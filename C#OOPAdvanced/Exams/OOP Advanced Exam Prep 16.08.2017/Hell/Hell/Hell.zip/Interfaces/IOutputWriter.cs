﻿public interface IOutputWriter
{
    void WriteLine(string line);
}

