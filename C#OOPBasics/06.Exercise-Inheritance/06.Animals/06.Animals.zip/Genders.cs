﻿public enum Genders
{
    Male,
    Female
}

